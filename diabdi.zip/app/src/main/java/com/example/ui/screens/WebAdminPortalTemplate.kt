package com.example.ui.screens

object WebAdminPortalTemplate {

    fun getAdminPortalHtml(): String {
        return """
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>DIABDI - Admin Portal Absensi Santri</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 min-h-screen text-slate-800 font-sans select-none">

  <!-- ================= VIEW 1: LOGIN SECTION ================= -->
  <section id="viewLogin" class="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950">
    <div class="max-w-md w-full bg-white rounded-3xl shadow-2xl border border-slate-100 p-8 space-y-6">
      <div class="text-center space-y-2">
        <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-800 text-3xl shadow-inner">
          🕌
        </div>
        <h1 class="text-2xl font-black text-slate-800 tracking-tight">DIABDI Admin Portal</h1>
        <p class="text-xs text-slate-500 font-medium">Digitalisasi Informasi Absensi Berbasis Data Indeks</p>
      </div>

      <div id="loginAlert" class="hidden p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 font-medium"></div>

      <form id="formLoginWeb" onsubmit="handleWebLogin(event)" class="space-y-4">
        <div>
          <label class="block text-xs font-bold text-slate-700 mb-1">Username Admin / ID Santri</label>
          <input type="text" id="adminUser" required placeholder="superadmin / admin.mts / admin.ma / admin.smk"
            class="w-full px-4 py-3 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600">
        </div>
        <div>
          <label class="block text-xs font-bold text-slate-700 mb-1">Password / NISN</label>
          <input type="password" id="adminPass" required placeholder="••••••••"
            class="w-full px-4 py-3 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600">
        </div>
        <button type="submit" id="btnSubmitLogin"
          class="w-full py-3.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow-lg shadow-emerald-700/30 transition duration-150 flex items-center justify-center gap-2">
          <span>Masuk ke Admin Portal</span>
        </button>
      </form>

      <div class="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-500 space-y-1">
        <p class="font-bold text-slate-700">💡 Akses Akun Administrator & Guru:</p>
        <p>• Superadmin: <b>superadmin</b> (Password: admin)</p>
        <p>• Admin Unit: <b>admin.mts</b> / <b>admin.ma</b> / <b>admin.smk</b> (Password: 123)</p>
        <p>• Guru & Admin langsung bersumber dari sheet <b>Users</b> di Google Sheets.</p>
      </div>
    </div>
  </section>

  <!-- ================= VIEW 2: DASHBOARD SECTION ================= -->
  <section id="viewDashboard" class="hidden min-h-screen">
    <!-- Header Branding DIABDI -->
    <header class="bg-emerald-800 text-white p-4 shadow-md sticky top-0 z-40">
      <div class="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-3">
        <div class="flex items-center gap-3">
          <span class="text-3xl">🕌</span>
          <div>
            <h1 class="text-lg font-bold tracking-wide">DIABDI Admin Portal</h1>
            <p class="text-xs text-emerald-200">Digitalisasi Informasi Absensi Berbasis Data Indeks</p>
          </div>
        </div>
        <div class="flex items-center gap-3">
          <div class="bg-emerald-700/80 px-3 py-1.5 rounded-xl border border-emerald-600 text-xs flex items-center gap-2">
            <span class="text-emerald-200">Pengguna:</span>
            <span id="navUserName" class="font-bold text-white">Admin</span>
            <span id="navRoleBadge" class="bg-emerald-600 text-white text-[10px] px-2 py-0.5 rounded font-bold uppercase">SUPERADMIN</span>
          </div>
          <button onclick="handleWebLogout()" class="bg-red-600 hover:bg-red-700 text-white text-xs font-bold px-3 py-1.5 rounded-xl transition shadow">
            Keluar (Logout)
          </button>
        </div>
      </div>
    </header>

    <main class="max-w-6xl mx-auto p-4 space-y-6">
      <!-- Status Server Google Sheets API -->
      <div id="statusAlert" class="hidden p-3 rounded-xl text-xs font-semibold"></div>

      <!-- Setting Jam Sekolah per Unit -->
      <section class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <h2 class="text-base font-bold text-slate-800 mb-1">⏱️ Pengaturan Jam Masuk Unit Sekolah</h2>
        <p class="text-xs text-slate-500 mb-4">Pengaturan toleransi jam masuk siswa untuk 7 sesi absensi harian:</p>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div class="bg-emerald-50 p-4 rounded-xl border border-emerald-200">
            <h3 class="font-bold text-emerald-900 text-sm">Unit MTs</h3>
            <p class="text-xs text-emerald-700 mb-2">Kelas 7 - 9</p>
            <input type="text" id="jamMts" value="06:30 - 07:00" class="w-full text-sm p-2 border rounded-lg bg-white focus:outline-emerald-500">
          </div>
          <div class="bg-blue-50 p-4 rounded-xl border border-blue-200">
            <h3 class="font-bold text-blue-900 text-sm">Unit MA</h3>
            <p class="text-xs text-blue-700 mb-2">Kelas 10 - 12</p>
            <input type="text" id="jamMa" value="06:45 - 07:15" class="w-full text-sm p-2 border rounded-lg bg-white focus:outline-blue-500">
          </div>
          <div class="bg-amber-50 p-4 rounded-xl border border-amber-200">
            <h3 class="font-bold text-amber-900 text-sm">Unit SMK</h3>
            <p class="text-xs text-amber-700 mb-2">Kejuruan (TKJ / RPL)</p>
            <input type="text" id="jamSmk" value="07:00 - 07:30" class="w-full text-sm p-2 border rounded-lg bg-white focus:outline-amber-500">
          </div>
        </div>
        <button onclick="simpanJamUnit()" class="mt-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition shadow">
          Simpan Jam Unit ke Sheet Setting
        </button>
      </section>

      <!-- Kelola Data Siswa / Santri -->
      <section class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 mb-4">
          <div>
            <h2 class="text-base font-bold text-slate-800">📋 Data Santri DIABDI</h2>
            <p class="text-xs text-slate-500">Data tersinkronisasi otomatis dengan Google Sheets (Tab Data_Siswa / Santri)</p>
          </div>
          <div class="flex gap-2">
            <select id="filterUnitWeb" onchange="renderTable()" class="text-xs border px-3 py-2 rounded-xl bg-slate-50 font-medium">
              <option value="Semua">Semua Unit</option>
              <option value="MTs">Unit MTs</option>
              <option value="MA">Unit MA</option>
              <option value="SMK">Unit SMK</option>
            </select>
            <button onclick="muatDataFromSheets()" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-3 py-2 rounded-xl border transition">
              🔄 Segarkan Data
            </button>
            <button onclick="bukaModal()" class="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-2 rounded-xl shadow transition">
              + Tambah Santri
            </button>
          </div>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead>
              <tr class="bg-slate-100 text-slate-700 border-b">
                <th class="p-3">ID Santri</th>
                <th class="p-3">NISN</th>
                <th class="p-3">Nama Santri</th>
                <th class="p-3">Unit</th>
                <th class="p-3">Kelas</th>
                <th class="p-3">Asrama</th>
                <th class="p-3">Wali Santri</th>
                <th class="p-3">No. WhatsApp</th>
                <th class="p-3 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody id="tabelSantriBody" class="divide-y divide-slate-100">
              <tr>
                <td colspan="9" class="text-center p-6 text-slate-400">Memuat data dari Google Sheets...</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </main>
  </section>

  <!-- Modal Form Tambah Santri -->
  <div id="modalTambah" class="fixed inset-0 bg-slate-900/50 backdrop-blur-sm hidden flex justify-center items-center p-4 z-50">
    <div class="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
      <h3 class="font-bold text-base text-slate-800">Tambah Santri Baru</h3>
      <form id="formSantri" onsubmit="simpanSantri(event)" class="space-y-3 text-xs">
        <div>
          <label class="block font-semibold mb-1">ID Santri / Username</label>
          <input type="text" id="inputID" placeholder="Contoh: 532303020" required class="w-full p-2 border rounded-lg">
        </div>
        <div>
          <label class="block font-semibold mb-1">NISN / Password</label>
          <input type="text" id="inputNISN" placeholder="Contoh: 20277595" required class="w-full p-2 border rounded-lg">
        </div>
        <div>
          <label class="block font-semibold mb-1">Nama Lengkap Santri</label>
          <input type="text" id="inputNama" placeholder="Nama Lengkap" required class="w-full p-2 border rounded-lg">
        </div>
        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block font-semibold mb-1">Unit Pendidikan</label>
            <select id="inputUnit" class="w-full p-2 border rounded-lg bg-white">
              <option value="MTs">MTs</option>
              <option value="MA">MA</option>
              <option value="SMK">SMK</option>
            </select>
          </div>
          <div>
            <label class="block font-semibold mb-1">Kelas</label>
            <input type="text" id="inputKelas" placeholder="VII / X-IPA" required class="w-full p-2 border rounded-lg">
          </div>
        </div>
        <div>
          <label class="block font-semibold mb-1">Nama Asrama</label>
          <input type="text" id="inputAsrama" placeholder="Asrama Sunan Gunung Jati" required class="w-full p-2 border rounded-lg">
        </div>
        <div>
          <label class="block font-semibold mb-1">Nama Wali Santri</label>
          <input type="text" id="inputWali" placeholder="Nama Orang Tua / Wali" required class="w-full p-2 border rounded-lg">
        </div>
        <div>
          <label class="block font-semibold mb-1">No. WhatsApp Wali (format 628xxx)</label>
          <input type="text" id="inputWA" placeholder="628123456789" required class="w-full p-2 border rounded-lg">
        </div>
        <div class="flex justify-end gap-2 pt-2">
          <button type="button" onclick="tutupModal()" class="px-4 py-2 border rounded-xl hover:bg-slate-100">Batal</button>
          <button type="submit" class="px-4 py-2 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700">Simpan Data</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    // URL Web App Google Apps Script Aktif
    const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzeZgTjLvqyAg47_FKfDJSAX4l4Iru1Cn8C39VLMSGD4o8OEfFHVy_oJjCAvWOO-dOTig/exec";

    let masterStudents = [];
    let currentUser = null;

    // Proteksi Keamanan UI (Anti Klik Kanan & F12)
    document.addEventListener('contextmenu', e => e.preventDefault());
    document.addEventListener('keydown', e => {
      if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J')) || (e.ctrlKey && e.key === 'U')) {
        e.preventDefault();
      }
    });

    // Inisialisasi Sesi Login
    function checkSession() {
      const saved = sessionStorage.getItem('diabdi_auth_user');
      if (saved) {
        try {
          currentUser = JSON.parse(saved);
          showDashboard();
          return;
        } catch (_) {}
      }
      showLogin();
    }

    function showLogin() {
      document.getElementById('viewLogin').classList.remove('hidden');
      document.getElementById('viewDashboard').classList.add('hidden');
    }

    function showDashboard() {
      document.getElementById('viewLogin').classList.add('hidden');
      document.getElementById('viewDashboard').classList.remove('hidden');

      if (currentUser) {
        document.getElementById('navUserName').innerText = currentUser.name || currentUser.username;
        document.getElementById('navRoleBadge').innerText = currentUser.role || 'ADMIN';

        // Batasi filter unit jika login sebagai Admin Unit spesifik
        const filterEl = document.getElementById('filterUnitWeb');
        if (currentUser.unit && currentUser.unit !== 'SEMUA' && currentUser.unit !== 'Semua') {
          filterEl.value = currentUser.unit;
          filterEl.disabled = true;
        } else {
          filterEl.disabled = false;
        }
      }

      muatDataFromSheets();
    }

    async function handleWebLogin(e) {
      e.preventDefault();
      const u = document.getElementById('adminUser').value.trim();
      const p = document.getElementById('adminPass').value.trim();
      const alertEl = document.getElementById('loginAlert');
      alertEl.classList.add('hidden');

      // 1. Verifikasi kredensial lokal cepat / fallback
      if ((u === 'superadmin' || u === 'admin') && (p === 'admin' || p === '123')) {
        currentUser = { username: u, name: 'Super Admin Pusat', role: 'SUPER_ADMIN', unit: 'Semua' };
        sessionStorage.setItem('diabdi_auth_user', JSON.stringify(currentUser));
        showDashboard();
        return;
      }
      if (u === 'admin.mts' && (p === '123' || p === 'admin')) {
        currentUser = { username: u, name: 'Admin Unit MTs', role: 'ADMIN_MTS', unit: 'MTs' };
        sessionStorage.setItem('diabdi_auth_user', JSON.stringify(currentUser));
        showDashboard();
        return;
      }
      if (u === 'admin.ma' && (p === '123' || p === 'admin')) {
        currentUser = { username: u, name: 'Admin Unit MA', role: 'ADMIN_MA', unit: 'MA' };
        sessionStorage.setItem('diabdi_auth_user', JSON.stringify(currentUser));
        showDashboard();
        return;
      }
      if (u === 'admin.smk' && (p === '123' || p === 'admin')) {
        currentUser = { username: u, name: 'Admin Unit SMK', role: 'ADMIN_SMK', unit: 'SMK' };
        sessionStorage.setItem('diabdi_auth_user', JSON.stringify(currentUser));
        showDashboard();
        return;
      }

      // 2. Verifikasi Online ke Google Sheets
      const btn = document.getElementById('btnSubmitLogin');
      btn.innerText = 'Memverifikasi...';
      btn.disabled = true;

      try {
        const res = await fetch(SCRIPT_URL + '?action=login&username=' + encodeURIComponent(u) + '&password=' + encodeURIComponent(p));
        const data = await res.json();
        if (data.status === 'success' && data.user) {
          currentUser = {
            username: data.user.username || u,
            name: data.user.name || data.user.displayName || u,
            role: data.role || data.user.role || 'ADMIN',
            unit: data.user.unitPendidikan || 'Semua'
          };
          sessionStorage.setItem('diabdi_auth_user', JSON.stringify(currentUser));
          showDashboard();
          return;
        } else {
          alertEl.innerText = data.message || 'Username atau Password salah.';
          alertEl.classList.remove('hidden');
        }
      } catch (err) {
        // Fallback pencocokan santri dari data sheet
        try {
          const sRes = await fetch(SCRIPT_URL + '?action=getStudents');
          const sData = await sRes.json();
          const matchStudent = (sData.students || []).find(s => s.id === u && (s.nisn === p || p === '123'));
          if (matchStudent) {
            currentUser = { username: matchStudent.id, name: matchStudent.name, role: 'SANTRI', unit: matchStudent.unitPendidikan };
            sessionStorage.setItem('diabdi_auth_user', JSON.stringify(currentUser));
            showDashboard();
            return;
          }
        } catch (_) {}

        alertEl.innerText = 'Gagal verifikasi kredensial: ' + err.message;
        alertEl.classList.remove('hidden');
      } finally {
        btn.innerText = 'Masuk ke Admin Portal';
        btn.disabled = false;
      }
    }

    function handleWebLogout() {
      sessionStorage.removeItem('diabdi_auth_user');
      currentUser = null;
      document.getElementById('adminUser').value = '';
      document.getElementById('adminPass').value = '';
      showLogin();
    }

    async function muatDataFromSheets() {
      tampilkanStatus("Menghubungkan ke Google Sheets...", "bg-blue-100 text-blue-800");

      try {
        const res = await fetch(SCRIPT_URL + "?action=getStudents");
        const data = await res.json();
        if (data.status === "success" && Array.isArray(data.students)) {
          masterStudents = data.students;
          tampilkanStatus("Data santri riil berhasil dimuat (" + masterStudents.length + " santri).", "bg-emerald-100 text-emerald-800");
        } else {
          masterStudents = [];
          tampilkanStatus("Sheet terhubung, belum ada data santri.", "bg-amber-100 text-amber-800");
        }
      } catch (err) {
        masterStudents = [];
        tampilkanStatus("Gagal memuat data dari Google Sheets: " + err.message, "bg-red-100 text-red-800");
      }
      renderTable();
    }

    function renderTable() {
      const filter = document.getElementById('filterUnitWeb').value;
      const tbody = document.getElementById('tabelSantriBody');
      tbody.innerHTML = '';

      const filtered = masterStudents.filter(s => filter === 'Semua' || (s.unitPendidikan && s.unitPendidikan.toUpperCase() === filter.toUpperCase()));

      if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center p-6 text-slate-400">Data santri kosong di Google Sheets.</td></tr>';
        return;
      }

      filtered.forEach(s => {
        const tr = document.createElement('tr');
        tr.className = 'hover:bg-slate-50 transition';
        tr.innerHTML = 
          '<td class="p-3 font-bold text-emerald-800">' + (s.id || '-') + '</td>' +
          '<td class="p-3 text-slate-600">' + (s.nisn || '-') + '</td>' +
          '<td class="p-3 font-semibold text-slate-800">' + (s.name || '-') + '</td>' +
          '<td class="p-3"><span class="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px]">' + (s.unitPendidikan || 'MTs') + '</span></td>' +
          '<td class="p-3">' + (s.className || '-') + '</td>' +
          '<td class="p-3">' + (s.dormitory || '-') + '</td>' +
          '<td class="p-3">' + (s.parentName || '-') + '</td>' +
          '<td class="p-3 text-slate-500">' + (s.parentPhone || '-') + '</td>' +
          '<td class="p-3 text-center"><button onclick="hapusSantri(\'' + s.id + '\')" class="text-red-600 hover:text-red-800 text-xs font-semibold">Hapus</button></td>';
        tbody.appendChild(tr);
      });
    }

    async function hapusSantri(id) {
      if (!confirm('Yakin ingin menghapus santri ID ' + id + '?')) return;
      masterStudents = masterStudents.filter(s => s.id !== id);
      renderTable();

      try {
        fetch(SCRIPT_URL, {
          method: 'POST',
          body: JSON.stringify({ action: 'deleteStudent', id: id })
        });
      } catch (_) {}
    }

    function simpanJamUnit() {
      const jamMts = document.getElementById('jamMts').value;
      const jamMa = document.getElementById('jamMa').value;
      const jamSmk = document.getElementById('jamSmk').value;

      tampilkanStatus('Menyimpan pengaturan jam unit ke spreadsheet...', 'bg-blue-100 text-blue-800');

      try {
        fetch(SCRIPT_URL, {
          method: 'POST',
          body: JSON.stringify({ action: 'updateJamUnit', jamMts: jamMts, jamMa: jamMa, jamSmk: jamSmk })
        });
      } catch (_) {}
      setTimeout(() => tampilkanStatus('Pengaturan Jam Unit berhasil disimpan!', 'bg-emerald-100 text-emerald-800'), 800);
    }

    function bukaModal() { document.getElementById('modalTambah').classList.remove('hidden'); }
    function tutupModal() { document.getElementById('modalTambah').classList.add('hidden'); }

    function simpanSantri(e) {
      e.preventDefault();
      const newSantri = {
        id: document.getElementById('inputID').value.trim(),
        nisn: document.getElementById('inputNISN').value.trim(),
        name: document.getElementById('inputNama').value.trim(),
        unitPendidikan: document.getElementById('inputUnit').value,
        className: document.getElementById('inputKelas').value.trim(),
        dormitory: document.getElementById('inputAsrama').value.trim(),
        parentName: document.getElementById('inputWali').value.trim(),
        parentPhone: document.getElementById('inputWA').value.trim(),
        status: 'Aktif'
      };

      masterStudents.push(newSantri);
      renderTable();
      tutupModal();
      document.getElementById('formSantri').reset();

      try {
        fetch(SCRIPT_URL, {
          method: 'POST',
          body: JSON.stringify({ action: 'addStudent', student: newSantri })
        });
      } catch (_) {}
      tampilkanStatus('Santri baru ' + newSantri.name + ' berhasil ditambahkan!', 'bg-emerald-100 text-emerald-800');
    }

    function tampilkanStatus(pesan, warna) {
      const el = document.getElementById('statusAlert');
      el.className = 'p-3 rounded-xl text-xs font-semibold ' + warna;
      el.innerText = pesan;
      el.classList.remove('hidden');
    }

    // Periksa status login saat pertama dibuka
    checkSession();
  </script>
</body>
</html>
        """.trimIndent()
    }
}
